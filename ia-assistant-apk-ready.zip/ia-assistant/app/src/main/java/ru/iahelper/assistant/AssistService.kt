package ru.iahelper.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AssistService : AccessibilityService() {
    companion object {
        var inst: AssistService? = null

        fun readScreen(): String {
            val root = inst?.rootInActiveWindow ?: return ""
            val sb = StringBuilder()
            walk(root, sb)
            return sb.toString().take(6000)
        }

        private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder) {
            if (n == null) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) {
                sb.append(t)
                if (n.isClickable) sb.append(" [кнопка]")
                if (n.isEditable) sb.append(" [поле ввода]")
                sb.append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), sb)
        }

        fun click(label: String): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            for (n in root.findAccessibilityNodeInfosByText(label)) {
                var x: AccessibilityNodeInfo? = n
                while (x != null) {
                    if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    x = x.parent
                }
            }
            return false
        }

        fun type(text: String): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
            val b = Bundle()
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        }

        fun global(action: Int): Boolean = inst?.performGlobalAction(action) == true
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
