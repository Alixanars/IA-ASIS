package ru.iahelper.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var rec: SpeechRecognizer? = null

    private fun js(s: String) = runOnUiThread { web.evaluateJavascript(s, null) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU")
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { js("onSpeakDone()") }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { js("onSpeakDone()") }
        })
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onDestroy() {
        rec?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface
        fun listen() = runOnUiThread {
            rec?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
            rec = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(res: Bundle?) {
                    val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    js("onVoice(${JSONObject.quote(t)},true)")
                }
                override fun onPartialResults(p: Bundle?) {
                    val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    js("onVoice(${JSONObject.quote(t)},false)")
                }
                override fun onError(e: Int) { js("onVoiceEnd()") }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(buf: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            r.startListening(i)
        }

        @JavascriptInterface
        fun stop() = runOnUiThread { rec?.stopListening() }

        @JavascriptInterface
        fun speak(t: String) { tts?.speak(t, TextToSpeech.QUEUE_ADD, null, "u") }

        @JavascriptInterface
        fun open(url: String): Boolean {
            return try {
                runOnUiThread {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                true
            } catch (e: Exception) { false }
        }

        @JavascriptInterface
        fun timer(sec: Int, label: String) = runOnUiThread {
            try {
                startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {}
        }

        @JavascriptInterface
        fun alarm(h: Int, m: Int, label: String) = runOnUiThread {
            try {
                startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h)
                    .putExtra(AlarmClock.EXTRA_MINUTES, m)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {}
        }

        @JavascriptInterface
        fun apps(): String {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val a = JSONArray()
            for (r in packageManager.queryIntentActivities(i, 0)) {
                a.put(r.loadLabel(packageManager).toString() + "|" + r.activityInfo.packageName)
            }
            return a.toString()
        }

        @JavascriptInterface
        fun launch(pkg: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            runOnUiThread { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            return true
        }

        @JavascriptInterface
        fun screen(): String = AssistService.readScreen()

        @JavascriptInterface
        fun click(label: String): Boolean = AssistService.click(label)

        @JavascriptInterface
        fun typeText(text: String): Boolean = AssistService.type(text)

        @JavascriptInterface
        fun global(name: String): Boolean = AssistService.global(
            when (name) {
                "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                else -> AccessibilityService.GLOBAL_ACTION_BACK
            }
        )

        @JavascriptInterface
        fun accEnabled(): Boolean = AssistService.inst != null

        @JavascriptInterface
        fun accSettings() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        @JavascriptInterface
        fun ask(id: Int, key: String, system: String, prompt: String) {
            Thread {
                var out: String
                var err = false
                try {
                    val body = JSONObject()
                        .put("model", "claude-sonnet-5-5")
                        .put("max_tokens", 1500)
                        .put("system", system)
                        .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                    val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.connectTimeout = 20000
                    c.readTimeout = 60000
                    c.setRequestProperty("content-type", "application/json")
                    c.setRequestProperty("x-api-key", key)
                    c.setRequestProperty("anthropic-version", "2023-06-01")
                    c.outputStream.use { it.write(body.toString().toByteArray()) }
                    val code = c.responseCode
                    val s = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                    val j = JSONObject(s)
                    if (code in 200..299) {
                        val ct = j.getJSONArray("content")
                        val sb = StringBuilder()
                        for (k in 0 until ct.length()) sb.append(ct.getJSONObject(k).optString("text"))
                        out = sb.toString()
                    } else {
                        err = true
                        out = j.optJSONObject("error")?.optString("message") ?: "HTTP $code"
                    }
                } catch (e: Exception) {
                    err = true
                    out = e.message ?: "Ошибка сети"
                }
                js("onAsk($id,${JSONObject.quote(out)},$err)")
            }.start()
        }
    }
}
